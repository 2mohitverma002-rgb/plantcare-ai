"""PlantCare severity module.

Extracted from new-efficient-net-code.ipynb (sections 2, 4 and 4b) so inference
and the RAG layer use exactly the maths the thresholds were validated against.

Pipeline
    ExG = 2G - R - B  ->  Otsu  ->  largest component        = green mask
    flood-fill inward from the four corners                  = leaf outline
    leaf outline AND NOT green                               = enclosed lesions
    + non-green hue inside the outline (USE_COLOUR_LESIONS)  = margin lesions
    lesion area / leaf area * 100                            = severity percent
    band lookup                       = Healthy/Mild/Moderate/High

Mask-quality gate: a "leaf" covering almost none or almost all of the frame
means segmentation failed, so severity is reported as "Unavailable" rather than
a confident wrong number.

Usage
    import severity as sev
    r = sev.severity_from_image(bgr)      # bgr from cv2.imread
    r["severity_level"]                   # 'Moderate'
    r["severity_percent"]                 # 12.4
    annotated = sev.annotate_image(bgr, "tomato_early_blight", 0.94, r)
"""

import cv2
import numpy as np

__all__ = ["analyse_leaf", "assess_severity", "severity_from_image",
           "severity_level", "annotate_image", "SEVERITY_ORDER"]

# ---------------------------------------------------------------- config
# Mirrors section 2 of the training notebook. Change here, not in callers.
WORK_SIZE = 512             # long side used for mask maths (speed)
CLOSE_RATIO = 0.02          # notch-closing kernel; 0.05+ swallows the leaf
MIN_LESION_RATIO = 0.0008   # blob must be >= this fraction of leaf area
MAX_LESION_RATIO = 0.30     # bigger than this is probably a mask failure
MAX_BOXES = 20
BOX_PADDING_RATIO = 0.01
USE_COLOUR_LESIONS = True   # also catch brown/yellow lesions on the leaf margin

# severity bands, percent of leaf area
HEALTHY_SEVERITY = 1.5
MILD_MAX = 10.0
MODERATE_MAX = 25.0

# leaf-mask sanity gate
MIN_LEAF_FRACTION = 0.05
MAX_LEAF_FRACTION = 0.95

SEVERITY_ORDER = ["Unavailable", "Healthy", "Mild", "Moderate", "High"]


# ---------------------------------------------------------------- masks
def _odd(value, minimum=3):
    value = max(minimum, int(value))
    return value + 1 if value % 2 == 0 else value


def fill_from_edge(mask):
    """Flood the background inward from all four corners; return the silhouette."""
    h, w = mask.shape
    flood = mask.copy()
    pad = np.zeros((h + 2, w + 2), np.uint8)
    for seed in [(0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)]:
        if flood[seed[1], seed[0]] == 0:
            cv2.floodFill(flood, pad, seed, 255)
    enclosed = cv2.bitwise_not(flood)          # holes only
    return cv2.bitwise_or(mask, enclosed)


def green_mask(bgr):
    """Excess-green + Otsu, cleaned, largest component only."""
    b, g, r = cv2.split(bgr.astype(np.float32))
    exg = 2.0 * g - r - b
    exg_u8 = cv2.normalize(exg, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

    _, mask = cv2.threshold(exg_u8, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    k = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE, (_odd(min(bgr.shape[:2]) * 0.012),) * 2)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, k, iterations=1)

    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
    if n > 1:
        biggest = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
        mask = np.where(labels == biggest, 255, 0).astype(np.uint8)
    return mask, exg_u8


def colour_lesion_mask(bgr, leaf_solid):
    """Non-green colours inside the leaf outline - catches lesions on the margin."""
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    hue, sat, val = cv2.split(hsv)

    healthy_green = ((hue >= 30) & (hue <= 90) & (sat > 40)).astype(np.uint8) * 255
    not_green = cv2.bitwise_and(cv2.bitwise_not(healthy_green), leaf_solid)

    usable = ((val > 25) & (val < 250)).astype(np.uint8) * 255   # drop shadow/specular
    return cv2.bitwise_and(not_green, usable)


def analyse_leaf(bgr):
    """Leaf mask, lesion mask, boxes (original scale) and severity percent."""
    h0, w0 = bgr.shape[:2]
    scale = WORK_SIZE / max(h0, w0)
    work = (cv2.resize(bgr, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
            if scale < 1 else bgr.copy())
    h, w = work.shape[:2]

    leaf_green, _ = green_mask(work)

    leaf_solid = fill_from_edge(leaf_green)
    if CLOSE_RATIO > 0:
        k = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE, (_odd(min(h, w) * CLOSE_RATIO),) * 2)
        leaf_solid = fill_from_edge(cv2.morphologyEx(leaf_solid, cv2.MORPH_CLOSE, k))

    lesion = cv2.bitwise_and(leaf_solid, cv2.bitwise_not(leaf_green))
    if USE_COLOUR_LESIONS:
        lesion = cv2.bitwise_or(lesion, colour_lesion_mask(work, leaf_solid))

    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (_odd(min(h, w) * 0.008),) * 2)
    lesion = cv2.morphologyEx(lesion, cv2.MORPH_OPEN, k, iterations=1)
    lesion = cv2.morphologyEx(lesion, cv2.MORPH_CLOSE, k, iterations=2)

    leaf_area = max(1, int(np.count_nonzero(leaf_solid)))
    severity = 100.0 * np.count_nonzero(lesion) / leaf_area

    n, labels, stats, _ = cv2.connectedComponentsWithStats(lesion, 8)
    pad = max(2, int(min(h, w) * BOX_PADDING_RATIO))
    scored = []
    for i in range(1, n):
        area = stats[i, cv2.CC_STAT_AREA]
        ratio = area / leaf_area
        if ratio < MIN_LESION_RATIO or ratio > MAX_LESION_RATIO:
            continue
        x, y = stats[i, cv2.CC_STAT_LEFT], stats[i, cv2.CC_STAT_TOP]
        bw, bh = stats[i, cv2.CC_STAT_WIDTH], stats[i, cv2.CC_STAT_HEIGHT]
        if bw < 4 or bh < 4:
            continue
        scored.append((area, (max(0, x - pad), max(0, y - pad),
                              min(w - 1, x + bw + pad), min(h - 1, y + bh + pad))))

    scored.sort(key=lambda t: t[0], reverse=True)
    inv = 1.0 / scale if scale < 1 else 1.0
    boxes = [tuple(int(v * inv) for v in box) for _, box in scored[:MAX_BOXES]]

    return {"leaf_mask": leaf_solid, "green_mask": leaf_green, "lesion_mask": lesion,
            "boxes": boxes, "severity": severity, "work_shape": (h, w)}


# ---------------------------------------------------------------- grading
def severity_level(percent, healthy_max=HEALTHY_SEVERITY,
                   mild_max=MILD_MAX, moderate_max=MODERATE_MAX):
    """% of leaf area covered by lesions -> severity band."""
    if percent is None or not np.isfinite(percent):
        return "Unavailable"
    if percent < healthy_max:
        return "Healthy"
    if percent < mild_max:
        return "Mild"
    if percent < moderate_max:
        return "Moderate"
    return "High"


def leaf_mask_quality(analysis):
    """Fraction of the frame the leaf mask claims. Outside the sane range = failure."""
    h, w = analysis["work_shape"]
    fraction = np.count_nonzero(analysis["leaf_mask"]) / float(max(1, h * w))
    return float(fraction), bool(MIN_LEAF_FRACTION <= fraction <= MAX_LEAF_FRACTION)


def assess_severity(bgr, analysis=None):
    """Full severity read-out for one leaf image.

    severity_percent    lesion area as % of leaf area (None if the mask failed)
    severity_level      Healthy | Mild | Moderate | High | Unavailable
    lesion_count        lesion blobs that passed the size filter
    largest_lesion_pct  biggest single lesion, % of leaf area
    leaf_fraction       how much of the frame the leaf mask covered
    mask_ok             False -> severity is not trustworthy for this image
    """
    if analysis is None:
        analysis = analyse_leaf(bgr)

    leaf_fraction, mask_ok = leaf_mask_quality(analysis)
    leaf_area = max(1, int(np.count_nonzero(analysis["leaf_mask"])))

    count, _, stats, _ = cv2.connectedComponentsWithStats(analysis["lesion_mask"], 8)
    blob_areas = [stats[i, cv2.CC_STAT_AREA] for i in range(1, count)]
    keep = [a for a in blob_areas
            if MIN_LESION_RATIO <= a / leaf_area <= MAX_LESION_RATIO]
    largest_pct = float(100.0 * max(keep) / leaf_area) if keep else 0.0

    percent = float(analysis["severity"]) if mask_ok else None
    level = severity_level(percent) if mask_ok else "Unavailable"

    return {"severity_percent": None if percent is None else round(percent, 2),
            "severity_level": level,
            "lesion_count": len(keep),
            "largest_lesion_pct": round(largest_pct, 2),
            "leaf_fraction": round(leaf_fraction, 3),
            "mask_ok": bool(mask_ok)}


def severity_from_image(bgr, crop=None):
    """Wrapper used by the RAG notebook.

    `crop` is accepted and ignored - thresholds here are global, not per-crop.
    Returns assess_severity() plus masks and boxes so callers can draw.
    """
    analysis = analyse_leaf(bgr)
    out = assess_severity(bgr, analysis)
    out.update({"boxes": analysis["boxes"],
                "leaf_mask": analysis["leaf_mask"],
                "lesion_mask": analysis["lesion_mask"],
                "work_shape": analysis["work_shape"],
                "severity_ratio": (None if out["severity_percent"] is None
                                   else round(out["severity_percent"] / 100.0, 5))})
    return out


# ---------------------------------------------------------------- drawing
def annotate_image(bgr, label, confidence, result=None, alpha=0.4):
    """Red lesion overlay + label bar. Mirrors the notebook's predict_image()."""
    if result is None:
        result = severity_from_image(bgr)
    out = bgr.copy()

    show_overlay = (result.get("mask_ok")
                    and result.get("severity_percent") is not None
                    and result["severity_percent"] >= HEALTHY_SEVERITY
                    and result.get("lesion_mask") is not None)
    if show_overlay:
        lesion_full = cv2.resize(result["lesion_mask"], (bgr.shape[1], bgr.shape[0]),
                                 interpolation=cv2.INTER_NEAREST)
        red = np.zeros_like(bgr)
        red[:, :, 2] = 255
        out = np.where(lesion_full[:, :, None] > 0,
                       cv2.addWeighted(out, alpha, red, 1 - alpha, 0), out)

    text = f"{str(label).replace('_', ' ').title()}  {confidence:.2f}"
    text += f"  |  {result['severity_level']}"
    if result.get("severity_percent") is not None:
        text += f" ({result['severity_percent']:.1f}%)"

    (tw, th), base = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.65, 2)
    cv2.rectangle(out, (0, 0), (min(tw + 16, out.shape[1]), th + base + 12), (0, 0, 0), -1)
    cv2.putText(out, text, (8, th + 6), cv2.FONT_HERSHEY_SIMPLEX, 0.65,
                (255, 255, 255), 2, cv2.LINE_AA)
    return out
