"""Central configuration.

Everything that differs between your laptop and a server is read from an
environment variable with a sensible local default, so nothing has to be edited
in code to deploy.

    PLANTCARE_SECRET_KEY    Flask session key. REQUIRED when DEBUG is off.
    PLANTCARE_CORS_ORIGIN   Allowed origin for /api/analyse. Default: none.
    PLANTCARE_MILVUS_URI    Milvus server URI. Set it to use a server instead of
                            the embedded / numpy backend.
    PLANTCARE_KB_BACKEND    Force a backend: "numpy" | "milvus" | "auto" (default).
    PLANTCARE_DEBUG         "1" to enable Flask debug. Default: off.
    PLANTCARE_ARTIFACT_DIR  Where the model + KB artifacts live. Default: ./artifacts
"""

import os
from pathlib import Path

# --- paths ---------------------------------------------------------------
BASE_DIR = Path(__file__).parent
DEFAULT_ARTIFACT_DIR = BASE_DIR / "artifacts"

# Optional override, for pointing at a freshly built KB without moving files. A path
# that does not exist falls back with a warning instead of taking the app down - an
# environment variable set to a stale or mistyped path should not look like a missing
# knowledge base.
_override = os.environ.get("PLANTCARE_ARTIFACT_DIR", "").strip().strip('"').strip("'")
if _override and not Path(_override).is_dir():
    print(f"[config] PLANTCARE_ARTIFACT_DIR={_override!r} is not a directory - "
          f"using {DEFAULT_ARTIFACT_DIR} instead.\n"
          f"[config] Clear it with:  Remove-Item Env:\\PLANTCARE_ARTIFACT_DIR")
    _override = ""
ARTIFACT_DIR = Path(_override) if _override else DEFAULT_ARTIFACT_DIR
UPLOAD_FOLDER = BASE_DIR / "uploads"
UPLOAD_FOLDER.mkdir(parents=True, exist_ok=True)

CNN_WEIGHTS = ARTIFACT_DIR / "best_cnn.pt"
CLASS_INDEX = ARTIFACT_DIR / "class_index.json"
SEVERITY_MODULE = ARTIFACT_DIR / "severity.py"

KB_MANIFEST = ARTIFACT_DIR / "kb_manifest.json"
KNOWLEDGE_GRAPH = ARTIFACT_DIR / "knowledge_graph.json"
KB_DB = ARTIFACT_DIR / "plantcare.db"          # Milvus Lite (Linux/macOS only)
KB_CHUNKS = ARTIFACT_DIR / "chunks.csv"        # numpy backend
KB_VECTORS = ARTIFACT_DIR / "embeddings.npy"   # numpy backend

# --- web -----------------------------------------------------------------
DEBUG = os.environ.get("PLANTCARE_DEBUG", "") == "1"
SECRET_KEY = os.environ.get("PLANTCARE_SECRET_KEY") or ("dev-only-key" if DEBUG else None)
CORS_ORIGIN = os.environ.get("PLANTCARE_CORS_ORIGIN", "")   # empty = no CORS headers
MAX_CONTENT_MB = 16
ALLOWED_EXT = {".png", ".jpg", ".jpeg", ".bmp", ".webp"}

# --- retrieval -----------------------------------------------------------
MILVUS_URI = os.environ.get("PLANTCARE_MILVUS_URI", "")
KB_BACKEND = os.environ.get("PLANTCARE_KB_BACKEND", "auto").lower()
RRF_K = 60          # reciprocal-rank-fusion constant
BM25_K1 = 1.5
BM25_B = 0.75

# --- inference -----------------------------------------------------------
CONFIDENCE_GATE = 0.70      # overridden by the checkpoint's config block if present
TOP_K = 3
IMG_SIZE = 224
MEAN = [0.485, 0.456, 0.406]
STD = [0.229, 0.224, 0.225]

# Report block -> (KB section_type, query template)
#
# These MUST match the section vocabulary written by notebook 02. The rewritten
# notebook emits seven section types (identity/overview/pathogen/transmission/
# symptom/prevention/treatment) instead of four, which is what lets "cause" and
# "reason" draw on genuinely different pools. The old mapping pointed both at
# "biology", so cross-block dedup always emptied one of them.
#
# kb_manifest.json carries the mapping the KB was built with; /health surfaces it.
SECTION_QUERIES = {
    "symptoms":   ("symptom",      "symptoms, appearance and identification of {name} on {crop} leaves"),
    "cause":      ("pathogen",     "causal organism and pathogen responsible for {name} in {crop}"),
    "reason":     ("transmission", "how {name} spreads, transmission and favourable conditions"),
    "precaution": ("treatment",    "control measures, fungicide spray, dosage and prevention of {name}"),
}

# Legacy four-type KBs (section_type in {general, symptom, biology, management}).
# Selected automatically when kb_manifest.json reports the old vocabulary.
SECTION_QUERIES_LEGACY = {
    "symptoms":   ("symptom",    "symptoms, appearance and identification of {name} on {crop} leaves"),
    "cause":      ("biology",    "causal organism and pathogen responsible for {name} in {crop}"),
    "reason":     ("biology",    "favourable weather conditions, humidity, temperature and spread of {name}"),
    "precaution": ("management", "control measures, fungicide spray, dosage and prevention of {name}"),
}

SECTION_HEADINGS = {
    "symptoms":   "Symptoms",
    "cause":      "Cause",
    "reason":     "Why it spread",
    "precaution": "Precautions and treatment",
}

# --- presentation --------------------------------------------------------
SEVERITY_COLOUR = {
    "Healthy": "#2e7d32",
    "Mild": "#fbc02d",
    "Moderate": "#ef6c00",
    "High": "#c62828",
    "Unavailable": "#546e7a",
}

SEVERITY_ADVICE = {
    "Healthy": "No action needed. Continue routine monitoring.",
    "Mild": ("Early stage. Remove affected leaves and monitor every 3-4 days"
             " before treating."),
    "Moderate": ("Established infection. Begin the control measures below and"
                 " re-check in 5-7 days."),
    "High": ("Severe. Act immediately and consult your local KVK or agriculture"
             " officer."),
    "Unavailable": ("Leaf area could not be measured reliably from this image -"
                    " severity not reported."),
}
