"""PlantCare Flask app.

Routes
    GET  /               upload form
    POST /analyse        run the pipeline, render the report page
    POST /api/analyse    same pipeline, JSON response (for an external frontend)
    POST /download       plain-text report download
    GET  /health         readiness check - tells you which artifacts are missing

Run:
    python app.py                       # http://127.0.0.1:5000
    PLANTCARE_DEBUG=1 python app.py     # auto-reload off; debug pages on

Production:
    set PLANTCARE_SECRET_KEY, leave PLANTCARE_DEBUG unset, and serve with
    waitress (Windows) or gunicorn (Linux):
        waitress-serve --port=5000 app:app
        gunicorn -w 2 -b 0.0.0.0:5000 app:app
"""

import io
import os
import traceback
from pathlib import Path

from flask import Flask, Response, jsonify, render_template, request, send_file
from werkzeug.utils import secure_filename

import config
import leaf_analysis
import report as report_mod

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = config.MAX_CONTENT_MB * 1024 * 1024

if not config.SECRET_KEY:
    raise RuntimeError(
        "PLANTCARE_SECRET_KEY is not set and debug mode is off. Set the environment "
        "variable, or run with PLANTCARE_DEBUG=1 for local development.")
app.secret_key = config.SECRET_KEY


@app.after_request
def add_cors(resp):
    # Only emits CORS headers when an origin is explicitly configured. The previous
    # version hardcoded "*", which let any site on the internet post to /api/analyse.
    if config.CORS_ORIGIN:
        resp.headers["Access-Control-Allow-Origin"] = config.CORS_ORIGIN
        resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
        resp.headers["Access-Control-Allow-Methods"] = "POST, OPTIONS"
    return resp


def _check_upload(files):
    if "image" not in files or files["image"].filename == "":
        return None, "Please choose a leaf photograph first."
    f = files["image"]
    ext = Path(secure_filename(f.filename)).suffix.lower()
    if ext not in config.ALLOWED_EXT:
        return None, f"Unsupported file type '{ext}'. Use JPG, PNG, BMP or WEBP."
    return f, None


@app.route("/")
def index():
    return render_template("index.html", max_mb=config.MAX_CONTENT_MB)


@app.route("/analyse", methods=["POST"])
def analyse():
    f, err = _check_upload(request.files)
    if err:
        return render_template("index.html", error=err,
                               max_mb=config.MAX_CONTENT_MB), 400
    try:
        bgr = leaf_analysis.read_upload(f)
        rep = report_mod.build(bgr, filename=secure_filename(f.filename))
    except FileNotFoundError as exc:
        return render_template("index.html", error=str(exc),
                               max_mb=config.MAX_CONTENT_MB), 500
    except Exception as exc:                        # noqa: BLE001
        traceback.print_exc()
        return render_template("index.html", error=f"Analysis failed: {exc}",
                               max_mb=config.MAX_CONTENT_MB), 500
    return render_template("result.html", r=rep)


@app.route("/api/analyse", methods=["POST", "OPTIONS"])
def api_analyse():
    if request.method == "OPTIONS":
        return "", 204
    f, err = _check_upload(request.files)
    if err:
        return jsonify({"ok": False, "error": err}), 400
    try:
        bgr = leaf_analysis.read_upload(f)
        rep = report_mod.build(bgr, filename=secure_filename(f.filename))
    except Exception as exc:                        # noqa: BLE001
        traceback.print_exc()
        return jsonify({"ok": False, "error": str(exc)}), 500

    payload = report_mod.to_json(rep)
    if request.args.get("images") == "1":
        payload["images"] = rep["images"]            # data: URIs, large
    return jsonify({"ok": True, "report": payload})


@app.route("/download", methods=["POST"])
def download():
    f, err = _check_upload(request.files)
    if err:
        return Response(err, status=400, mimetype="text/plain")
    bgr = leaf_analysis.read_upload(f)
    rep = report_mod.build(bgr, filename=secure_filename(f.filename))
    buf = io.BytesIO(report_mod.to_text(rep).encode("utf-8"))
    return send_file(buf, mimetype="text/plain", as_attachment=True,
                     download_name=f"plantcare_report_{rep['label']}.txt")


@app.route("/health")
def health():
    kb_numpy = config.KB_CHUNKS.exists() and config.KB_VECTORS.exists()
    checks = {
        "cnn_weights": config.CNN_WEIGHTS.exists(),
        "class_index": config.CLASS_INDEX.exists(),
        "severity_module": config.SEVERITY_MODULE.exists(),
        "kb_manifest": config.KB_MANIFEST.exists(),
        "knowledge_base": kb_numpy or config.KB_DB.exists(),
    }
    missing = [k for k, v in checks.items() if not v]

    body = {"ok": not missing, "artifacts": checks, "missing": missing,
            "artifact_dir": str(config.ARTIFACT_DIR)}
    if not missing:
        try:
            import classifier
            import knowledge_base as kb
            body["knowledge_base_info"] = kb.health()
            body["classes"] = len(classifier.class_names())
            body["confidence_gate"] = classifier.confidence_gate()
            body["warnings"] = classifier.warnings()
        except Exception as exc:                     # noqa: BLE001
            body["ok"] = False
            body["load_error"] = f"{type(exc).__name__}: {exc}"
            return jsonify(body), 503
    return jsonify(body), (200 if body["ok"] else 503)


@app.errorhandler(413)
def too_large(_):
    return render_template("index.html",
                           error=f"That file is larger than {config.MAX_CONTENT_MB} MB.",
                           max_mb=config.MAX_CONTENT_MB), 413


def _startup_check():
    kb_ok = ((config.KB_CHUNKS.exists() and config.KB_VECTORS.exists())
             or config.KB_DB.exists())
    missing = [n for n, ok in [
        ("best_cnn.pt", config.CNN_WEIGHTS.exists()),
        ("class_index.json", config.CLASS_INDEX.exists()),
        ("severity.py", config.SEVERITY_MODULE.exists()),
        ("chunks.csv + embeddings.npy (or plantcare.db)", kb_ok)] if not ok]
    if missing:
        print("\n  MISSING ARTIFACTS:", ", ".join(missing))
        print(f"  Put them in: {config.ARTIFACT_DIR}")
        print("  The app will still start; /health lists what is missing.\n")


if __name__ == "__main__":
    _startup_check()
    # use_reloader=False: the reloader starts a second process, and both would open
    # the Milvus Lite database - the second one fails on the lock file.
    app.run(host=os.environ.get("PLANTCARE_HOST", "127.0.0.1"),
            port=int(os.environ.get("PLANTCARE_PORT", "5000")),
            debug=config.DEBUG,
            use_reloader=False)
