"""EfficientNet-B0 classifier wrapper.

Loaded once on first use and kept in memory. CPU is fine - a single 224px forward
pass is a few tens of milliseconds.
"""

import json

import cv2
import numpy as np
import torch
import torch.nn as nn
from torchvision import models, transforms

import config

_model = None
_tf = None
_classes = None
_gate = config.CONFIDENCE_GATE
_warnings = []


def _build(num_classes):
    m = models.efficientnet_b0(weights=None)
    m.classifier = nn.Sequential(
        nn.Dropout(0.3),
        nn.Linear(m.classifier[1].in_features, num_classes))
    return m


def load():
    global _model, _tf, _classes, _gate
    if _model is not None:
        return

    if not config.CNN_WEIGHTS.exists():
        raise FileNotFoundError(
            f"{config.CNN_WEIGHTS} missing - copy best_cnn.pt from Kaggle into artifacts/")
    if not config.CLASS_INDEX.exists():
        raise FileNotFoundError(f"{config.CLASS_INDEX} missing - copy class_index.json too")

    raw = json.loads(config.CLASS_INDEX.read_text())
    if isinstance(raw, dict):
        if all(str(k).lstrip("-").isdigit() for k in raw):          # {"0": "grape_..."}
            _classes = [raw[k] for k in sorted(raw, key=lambda x: int(x))]
        else:                                                        # {"grape_...": 0}
            _classes = [k for k, _ in sorted(raw.items(), key=lambda kv: kv[1])]
    else:
        _classes = list(raw)

    ckpt = torch.load(config.CNN_WEIGHTS, map_location="cpu", weights_only=False)
    state = ckpt.get("state_dict", ckpt.get("model_state_dict", ckpt))
    cfg = ckpt.get("config", {}) if isinstance(ckpt, dict) else {}

    if not cfg:
        _warnings.append(
            "Checkpoint has no 'config' block, so image size / normalisation come from "
            "config.py. If notebook 01 trained with different values, this app "
            "preprocesses differently from training and nothing will flag it. Add a "
            "config= dict to the torch.save in notebook 01.")
        print("[classifier] WARNING", _warnings[-1])

    size = int(cfg.get("img_size", config.IMG_SIZE))
    mean = cfg.get("mean", config.MEAN)
    std = cfg.get("std", config.STD)
    _gate = float(cfg.get("confidence_gate", config.CONFIDENCE_GATE))

    _model = _build(len(_classes))

    # strict=True on purpose. With strict=False a shape or naming mismatch loads a
    # randomly-initialised head and the app serves confident nonsense in silence.
    try:
        _model.load_state_dict(state, strict=True)
    except RuntimeError as exc:
        missing = sorted(set(_model.state_dict()) - set(state))[:6]
        extra = sorted(set(state) - set(_model.state_dict()))[:6]
        raise RuntimeError(
            f"Checkpoint does not match the model definition.\n"
            f"  missing in checkpoint : {missing}\n"
            f"  unexpected in checkpoint: {extra}\n"
            f"  class_index.json has {len(_classes)} classes\n"
            f"Original error: {exc}") from exc

    _model.eval()
    _tf = transforms.Compose([
        transforms.ToPILImage(),
        transforms.Resize(int(size * 1.14)),
        transforms.CenterCrop(size),
        transforms.ToTensor(),
        transforms.Normalize(mean, std),
    ])
    print(f"[classifier] {len(_classes)} classes | img {size} | gate {_gate:.0%}")


def class_names():
    load()
    return list(_classes)


def confidence_gate():
    load()
    return _gate


def warnings():
    return list(_warnings)


@torch.no_grad()
def predict(bgr, topk=config.TOP_K):
    """Returns (label, confidence, [(label, prob), ...])."""
    load()
    x = _tf(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)).unsqueeze(0)
    probs = torch.softmax(_model(x), 1)[0].numpy()
    order = probs.argsort()[::-1][:topk]
    top = [(_classes[int(i)], float(probs[int(i)])) for i in order]
    return top[0][0], top[0][1], top


def pretty(label):
    """grape_black_rot -> ("Grape", "Black Rot", "Grape Black Rot")."""
    parts = str(label).split("_")
    crop = parts[0].title()
    disease = " ".join(parts[1:]).title() if len(parts) > 1 else ""
    return crop, disease, f"{crop} {disease}".strip()
